# MANDELBROT MIDI v0.2a — Contour

Eigenständiges JUCE-8.0.6-VST3 für Windows 10 x64 / Ableton Live 11. Neuer Plug-in-Code `MbMa`, Bundle-ID `org.fractallab.mandelbrotmidi.v02a`, Produktname **MANDELBROT MIDI v0.2a**. v0.1 (`MbMd`, MANDELBROT MIDI) bleibt separat ladbar. Das Projekt liegt auf GitHub im Ordner `v02a`; der Repository-Root bleibt v0.1.

**Windows-Build und automatisierte Tests erfolgreich:** [Lauf #6](https://github.com/paddo1210/mandelbrot-midi/actions/runs/38142808818). [v0.2a VST3-ZIP herunterladen](https://github.com/paddo1210/mandelbrot-midi/actions/runs/38142808818/artifacts/11703761675). Praktische Ableton-Abnahme noch ausstehend.

## Implementiert

- GEN / CTRL, 16 Sechzehntel, vier Viertel pro Zyklus, Host-PPQ/BPM, Gate und monophone Note-Offs.
- Contour: unabhängige X/Y, Zoom multiplier × 10^Zoom exponent, Radius, Kreis oder horizontale Linie, N=64/128/256/512.
- Pitch/Velocity-Quellen wählbar, drei unabhängige Amounts. Rhythm v0.2a ausschließlich MASK.
- Low/High, Root und Scale definieren erlaubte MIDI-Noten. Kein MIDI-Clipping außerhalb der Skala.
- Gespeicherte Basissequenz: 16 Degrees, On-Schalter und individuelle CTRL-Velocities; Berechnung überschreibt diese nicht.
- Alle Patternparameter inklusive Mode werden am nächsten Vier-Viertel-Zyklus übernommen. Start/Seek berechnet sofort den aktuellen Zustand; Start zwischen Steps wartet auf die nächste Sechzehntel. Run/Panic/Stop beendet Noten im nächsten aufgerufenen Block.
- Einfacher Parametereditor plus Tabelle: E, Bewegung, H, Fluchtindex, MIDI, On und projizierte Basis pro Step. Angezeigt wird das übernommene Pattern, nicht nur die angeforderten Reglerwerte. Anzeigen sind atomare Telemetrie, kein wissenschaftlich konsistenter Snapshot während eines Updates.
- 72 automatisierbare Parameter, schema-versionierter APVTS-Zustand. Bestehende APC20-Remote-Scripts werden nicht geändert. Positionsslots sind noch nicht implementiert; Positionen können über Live-Set-/Plug-in-Zustände gespeichert werden.

## Mathematik und Mapping

c_s=(X+iY)+(Radius/Zoom)u_s. Kreis: u_s=exp(2πis/16). Linie: u_s=−1+2s/15. Zoom und Radius sind eigene Regler; die tatsächliche Ausdehnung ist Radius/Zoom. X/Y sind floatbasierte Hostparameter mit 10^−6-Schrittweite, Rechnung erfolgt in Double. Dies ist keine Deep-Zoom-Navigation; bis Zoom 10^4 kann die absolute Parametergenauigkeit die Feinsteuerung deutlich begrenzen. Kein unbegründetes Präzisionsversprechen.

z_0=0,z_(n+1)=z_n²+c. Erste Flucht bei |z_n|²>4. K=Fluchtindex oder N, falls nicht geflohen. Nicht geflohen bedeutet **unresolved at N**, keinen allgemeinen Zugehörigkeitsbeweis.

E=(1/K)Σ min(|z_n|²/4,1). Bewegung V=(1/K)Σ min(|z_n−z_(n−1)|/4,1). Beides beschreibt endliche Bahnpräfixe; weder Chaosmaß noch physikalische Energie. H_s=min(|E_s−E_prev|/0.05,1). Kreis schließt bei Step 1 zu Step 16; Linie verwendet H_1=0. Keine künstliche Linien-Schließkante.

Pitch-Quelle E, V, Smooth Escape oder Integer Escape. Smooth Escape: nach Flucht n zwei weitere Iterationen, m=n+2, μ=m+1−ln(ln|z_m|)/ln2, f=clamp(log(1+max(μ,0))/log65,0,1). Nicht geflohene Punkte erhalten nur für dieses musikalische Mapping f=1; der Status bleibt unresolved. Integer Escape verwendet n/N oder 1 als ausdrückliche Vergleichsquelle. E/V verwenden ihren direkten Wert.

Pitch: Liste S sämtlicher erlaubter Skalennoten in Low…High. b ist der Index des Root (GEN) oder Basis-Degree (CTRL), bei Bedarf zur nächstgelegenen erlaubten Note projiziert; bei Gleichstand die tiefere. GEN: Index=round(b+A_pitch(round((len(S)−1)f)−b)). CTRL: Index=b+round(A_pitch·PitchSpan·(2f−1)). Index innerhalb S begrenzen. **Amount=0 reproduziert das ursprüngliche CTRL-Pattern exakt, wenn seine Töne innerhalb des erlaubten Bereichs liegen.** Außerhalb liegende Basistöne werden für sichere Wiedergabe projiziert; die gespeicherten Degrees bleiben unverändert, die Tabelle markiert dies. Kein erlaubter Skalenton → stummes Pattern und Warnung. Bei Low>High wird High auf Low begrenzt.

MASK: On_s=BasisOn_s AND (H_s≥RhythmAmount·Threshold). Jede Entfernung ist aus H und Schwelle ableitbar. Amount=0 bewahrt sämtliche Basispause/-Noten; zurückdrehen stellt die Maske wieder her. Es werden keine neuen Basissteps gesetzt. Gleichheit bleibt aktiv. Homogene Konturen können bei positiver Schwelle vollständig stumm werden. Das ist das Ergebnis des dokumentierten Mappings, kein Fehler, keine Behauptung, die Menge enthalte einen musikalischen Rhythmus.

Velocity: clamp(BasisVelocity_s+round(A_velocity·VelocitySpan·(2g−1)),1,127), g=E,V oder H. CTRL verwendet Step-Velocities, GEN globale Basisvelocity.

Die Skala, Register, Gain-Konstanten, Reihenfolge und Zeitzuordnung sind musikalische Interpretationen. Die Bahnen werden niemals durch Zufall ersetzt. Quellen und siebenteilige Bewertung der Merkmale stehen in [CONCEPT.md](CONCEPT.md).

## Automation, Determinismus und Echtzeit

Berechnung synchron am Transportstart/Seek und an Zyklusgrenzen, ohne Worker-Rennen. Pro Pattern höchstens 16×512 Hauptiterationen plus maximal 32 Glättungsiterationen. Feste Arrays, keine Engine-Allokation, keine Locks; die JUCE-MIDI-Pufferverwaltung bleibt Host-/Wrapper-abhängig. Mehrere Zyklusgrenzen in ungewöhnlich großen Blöcken können mehrere Berechnungen auslösen. CPU-Timing ist zu messen, besonders bei kleinen Audiopuffern.

Deterministisch für identische übernommene Parametersnapshots, gleiche Rechenversion und gleiche Host-Zeitleiste. Die automatischen Core-Tests liefern Parameteränderungen zu exakt denselben Samplepositionen, auch bei wechselnder Blockgröße. Der Prozessor liest APVTS dagegen **einmal pro Block**. Die v0.2a-Schnittstelle hat keine samplegenauen VST3-Automations-Offsets; Automation innerhalb des Blocks an einer Zyklusgrenze kann zwischen Puffergrößen unterschiedlich sichtbar werden. Auch unabhängige APVTS-Atomics sind keine transaktionale Mehrparameteraufnahme. Daher kein Versprechen beliebiger samplegenauer oder puffergrößenunabhängiger Host-Automation. Für verlässlichen Live-Einsatz Automation/Mode vor der gewünschten Zyklusgrenze setzen, danach wiederholte Aufnahmen vergleichen. Samplegenaue Wrapper-/Event-Integration ist ein eigener nächster technischer Prüfpunkt.

## Build / Installation

VS2022 / MSVC v143 / Windows SDK / CMake≥3.22, Git. Im v02a-Ordner:

```powershell
cmake --preset windows-vs2022
cmake --build --preset release --parallel 4
ctest --preset release --verbose
```

Oder vom Repository-Root:

```powershell
cmake -S v02a -B build-v02a -G "Visual Studio 17 2022" -A x64
cmake --build build-v02a --config Release --parallel 4
ctest --test-dir build-v02a -C Release --output-on-failure
```

VST3: `build-v02a/MandelbrotMidiV02a_artefacts/Release/VST3/MANDELBROT MIDI v0.2a.vst3`. Komplettes Bundle installieren, vorhandene v0.1-Datei behalten. Keine .lib/.exp-Dateien installieren. JUCE-Lizenz vor Weitergabe prüfen.

Live: v0.2a auf Quell-MIDI-Spur. Zweite Spur mit Synth: MIDI From → Quellspur → **MANDELBROT MIDI v0.2a**, Monitor In. Transport starten. MIDI-Eingangsbus exponiert wie im korrigierten v0.1-Build; Eingangsereignisse werden verworfen, Audio bleibt stumm. Bestehendes Zwei-Spur-Routing muss praktisch erneut geprüft werden.

APC20 über Live Configure/MIDI Map: X/Y, Zoom, Pitch/Rhythm/Velocity Amount, Radius, Gate; Mode auf Taste. Bestehende Controller-Scripts bleiben unangetastet. Die Fähigkeit zur Navigation hängt von deren Belegung und Live-Takeover ab. Keine eigenen LED-/CC-Protokolle.

## Roadmap

**v0.2b als nächste mathematische Entwicklungsstufe:** Orbit-Ansicht für ein einziges c, definierter Vorlauf B, tatsächliche z_n-Folge; Periodenkandidaten mit Toleranz und Beobachtungsfenster, klare Trennung von exaktem Zyklus, numerischem Kandidaten, Präperiodizität und Attraktion. Keine Gleichsetzung mit Chaos; keine Periodenbehauptung aus bloßer endlicher Ähnlichkeit. Beispiele 0,−1,−2 als Referenzen. Orbit ist zentral, kein optionaler dekorativer Effekt.

Rhythm danach: GENERATE und HYBRID, explizite Merkmals-/Schwellenregeln für neue Ereignisse und Basismasken, protokollierbare Entscheidungen je Step. Keine Zufallsfunktion. Außerdem Positionsslots, relative Fein-Navigation und samplegenaue Automationsintegration untersuchen.

Weitere Abnahme und aktuellen Prüfstatus siehe [TEST_REPORT.md](TEST_REPORT.md).
