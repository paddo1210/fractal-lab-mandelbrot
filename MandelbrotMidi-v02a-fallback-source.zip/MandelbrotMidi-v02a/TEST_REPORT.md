# v0.2a Prüfstatus

Stand 11.10.2026. **Windows-Build und Tests erfolgreich** in GitHub Actions, finaler Lauf [#6](https://github.com/paddo1210/mandelbrot-midi/actions/runs/38142808818), Code-/Teststand `04d2b7311e169d75a924ea248e57fa637ebf655d`. Beide Matrixjobs (v0.1 und v0.2a) erfolgreich; v0.2a-Bundle mit eigenem Identifier erzeugt. Der finale Preset-Test setzt die Prozessorsamplerate und verlangt echte Note-Ons, um einen Vergleich zweier leerer Puffer auszuschließen.

Bereits im vorherigen Lauf #5 wurden beide v0.2a-Tests mit `100% tests passed, 0 tests failed out of 2` ausgeführt. Die Core-Messung ergab dort im Mittel 0.134547 ms pro Worst-Budget-Pattern (1000 Berechnungen) auf dem GitHub-Runner. Das ist kein Echtzeit-Maximum und kein Messergebnis für den Zielrechner.

Lokale Ausführung wurde durch Zugriffsrechte auf den portablen Compiler und automatisch abgelehnte Sandbox-Eskalation verhindert. Diese Grenze wurde durch den echten Windows-CI-Lauf aufgefangen. **Kein eigener Live-v0.2a-Test.**

Downloads (GitHub-Anmeldung erforderlich): [v0.2a](https://github.com/paddo1210/mandelbrot-midi/actions/runs/38142808818/artifacts/11703761675), [v0.1-Rückfallversion](https://github.com/paddo1210/mandelbrot-midi/actions/runs/38142808818/artifacts/11703831246). Nur die .vst3-Bundles werden verpackt.

## Automatische Tests

`engine_tests`: direkte C++-Engine, echte Orbits 0/−1/−2/1, strikter Fluchtradius, Fluchtindex, unresolved, Konjugationssymmetrie, getrennte Amounts, exakte gültige CTRL-Basis, reversible MASK und deren Step-Regel, Scale/Range über mehrere Roots/Quellen, leere Skalennotenliste, NaN/Inf-Sanitization, Linienkante, Zoom, konstante und automatisierte Eventzeitleisten bei 64/511/2048 Samples, synchronisierte Modusübernahme, Stop/Loop/Panic/Seek/negative PPQ/Reset/Sample-Rate und Tempo 60/180. Zusätzlich 1000 Worst-Budget-Patternberechnungen als gemitteltes Timing; kein Echtzeit-Worst-Case-Nachweis.

`processor_tests`: JUCE/APVTS-Roundtrip sämtlicher Parameter, identische MIDI-Bytes zweier Prozessoren nach Restore, exponierter MIDI-Eingangsbus/-Ausgang, stummer Audioausgang, ungültiger Zustand und Panic. GUI-Layout und VST3-Host-Wrapper sind damit noch nicht praktisch validiert.

## Zwingende Ableton-Abnahme

1. v0.1 und v0.2a gemeinsam scannen, separat laden; keine alte Session/Plug-in-ID ersetzen.
2. Zwei-Spur-MIDI-Routing inklusive v0.2a-Auswahl prüfen; Wavetable verwenden und MIDI aufnehmen.
3. CTRL alle drei Amounts=0: gültige Basistöne, Pausen und individuelle Velocities unverändert. Bei Range-Projektion Anzeige gegen Aufnahme prüfen; das gespeicherte Pattern muss nach erweitertem Bereich zurückkehren.
4. MASK steigern/zurückdrehen: entfernte Steps exakt aus H≥A·T ableiten, ursprüngliche Pausen bleiben Pausen. Kreis/Line und homogene Region testen.
5. Änderungen an Mode, Navigation, Amounts, Gate/Range mitten im Zyklus: erst bei nächster Vier-Viertel-Grenze wirksam; Start/Seek als dokumentierte Ausnahmen prüfen.
6. Live-Automation mehrfach aufnehmen: gleiche Puffergröße, dann 64/512/2048, Offline/Realtime, besonders Änderungen dicht an Zyklusgrenzen. Unterschiede protokollieren; Core-Tests beweisen keine samplegenaue JUCE-Host-Automation.
7. Stop, Seek, Loop mit ungerader Grenze, Run/Panic, Audio-Gerätewechsel, Plug-in-Bypass/Entfernung während Note: keine hängenden Zielinstrumentnoten. Nach Suspend/Entfernung muss der Host bzw. das Zielinstrument resetten.
8. Live-Set und Plug-in-Preset speichern/neu öffnen: alle 72 Parameter/Basissteps und identische Sequenz prüfen. v0.1-Presets werden nicht automatisch importiert.
9. Maximales N, Zoom, schnelle APC-Faderwechsel, 48/96 kHz bei 64/512/2048: CPU-Spitzen und Aussetzer prüfen. Parametereditor und Merkmaltabelle visuell prüfen.
10. Hörvergleiche aus CONCEPT.md durchführen; keinerlei Aussage über musikalischen Mehrwert oder wahrgenommene Selbstähnlichkeit ohne Beobachtung.

Bestehende APC20-Remote-Scripts wurden nicht verändert. Position-only-Slots, Orbit und Rhythm GENERATE/HYBRID sind geplant und noch nicht implementiert.
